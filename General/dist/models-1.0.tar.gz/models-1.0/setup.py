from setuptools import setup

setup(

    name = "models",
    version = "1.0",
    description = "Realizando el primer paquete redistribuido",
    author = "Aguirre Florencia",
    author_email= "floraguirre1598@gmail.com",

    packages = ["paquetes1"]

)